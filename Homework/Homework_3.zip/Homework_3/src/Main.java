public class Main {
    public static void main(String[] args) {

        // Задание 5
        // Используя IntelliJ IDEA, создайте класс Main. Проверьте, можно ли создать переменные со следующими именами:
        // uberflu? , _Identifier , \u006fIdentifier , &myVar , myVariab1le.

//        int uberflu? = 2; // Нельзя из-за вопросительного знака
//        System.out.println(uberflu?);

        int _Identifier = 5;
        System.out.println(_Identifier); // Можно


//        int \u006fIdentifier; Нельзя из-за слеша

//        int &myVar;  Нельзя :)


        int myVariab1le = 10;
        System.out.println(myVariab1le); // Можно




    }
}
