public class Main {
    public static void main(String[] args) {

        //Задание 4
        //Используя IntelliJ IDEA, создайте проект. Создайте необходимое количество переменных типа char,
        // каждой переменной присвойте значение одного символа в формате UNICODE.
        // Выведите в консоль фразу «Здравствуйте, ВАШЕ_ИМЯ !».

        char y = 'Я';
        char a = 'Р';
        char r = 'О';
        char o = 'С';
        char s = 'Л';
        char l = 'А';
        char B = 'В';
        char v = '!';
        System.out.println("Здравствуйте, " + y + a + r + o + s + l + B + v);
    }
}
