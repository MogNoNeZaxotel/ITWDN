public class main {
    public static void main(String[] args) {

        //Задание 2
        //Используя IntelliJ IDEA, создайте проект. Дано значение числа pi, которое равно 3,141592653 и значение
        // числа Эйлера е, которое равно 2,7182818284590452. Создайте две переменные, присвойте им значения числа pi и
        // числа е и выведите их на экран без потери точности.

        final double PI = 3.141592653;
        System.out.println(PI);
        final double E = 2.7182818284590452;
        System.out.println(E);






    }
}
